package com.daniyalak.fgroup7infs.callback

interface stepsCallback {

    fun subscribeSteps(steps: Int)
}